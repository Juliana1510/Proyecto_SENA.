<?php

require_once 'crud_producto.php';
require_once 'conexion.php';
require_once 'productos.php';     
$crud=new mach_acces();
$producto= new productos();
$listaproducto=$crud->mostrar_prod();


$db = database::conectar();

if(isset($_REQUEST['action']))
{
    switch ($_REQUEST['action'])
    {
        case 'eliminar':
          $num_prod = $_POST["cod_prod"];
          $delete=new mach_acces();
          $delete-> Delete_prod($_POST["cod_prod"]);
        break;
    }   
}
?>


<html>
	<head>
      <link rel="shortcut icon" href="../imagenes/icono.png">
      <title>Pagina principal</title>
      <link rel="stylesheet" href="./css/estilo.css"/>
  </head>
      <body>
        <nav id="menu-h">
          </a>
            <ul>
              <li><a  href="administra_prod.php#insertaprod">Producto Nuevo</a></li>
              <li><a  href="#">Papelera</a></li> <!--falta archivo de papelera-->
              <li><a  href="./html/index.html">Salir</a></li>
            </ul>
        </nav><br>
<!--EDITADO-->
        <SELECT class="filtro" NAME=""> 
          <option disabled selected>Filtrar</option>
          <OPTION VALUE="">Medicamentos
          <OPTION VALUE="">Populares
          <OPTION VALUE="">Cosmeticos
          <OPTION VALUE="">Droga Blanca
        </SELECT>

        <li><a class="btn" href="#">REGISTRAR VENTAS</a></li><!--falta archivo de registro de venta-->
        <li><a class="btn" href="./html/Factura.html">FACTURAS</a></li>
        <li><a class="btn" href="#">REPORTE DE VENTAS</a></li><!--falta archivo de reporte de ventas-->
        <li><a class="btn" href="./html/Historial_ventas.html">HISTORIAL DE VENTAS</a></li>

  <table summary="tabla admin">
    <br><br><br>
  <thead>
    <tr>
      <th scope="col">Codigo</th>
      <th scope="col">Nombre</th>
      <th scope="col">valor</th>
      <th scope="col">Cantidad Disponible</th>
      <th scope="col">Costo</th>
      <th scope="col">Marca</th>
      <th scope="col">Proveedor</th>
      <th scope="col">Tipo</th>
      <th scope="col">Observacion</th>
      <th scope="col">Editar/Eliminar</th>
    </tr>
  </thead>
  <tbody>
  <?php foreach ($listaproducto as $producto) {?>
    <tr>
      <td><?php $id_prod=$producto->getcod_producto(); echo $producto->getcod_producto() ?></td> 
      <td><?php echo $producto->getnom_producto() ?></td>
      <td><?php echo $producto->getvalor_producto() ?></td>
      <td><?php echo $producto->getcantidad_disp() ?></td>
      <td><?php echo $producto->getcosto() ?></td>
      <td><?php echo $producto->getfk_marca() ?></td>
      <td><?php echo $producto->getfk_proveedor_id() ?></td>
      <td><?php echo $producto->getfk_tipo_prod() ?></td>
      <td><?php echo $producto->getobservacion_prod() ?></td>
      <td>
        <!--actualizar producto-->
        <form action="administra_prod.php" method="POST">
          <input type="hidden" name="id_prod" value="<?php echo $id_prod?>"><!--envia id de producto-->
          <input type="submit" value="Editar">
        </form>

        <!-- eliminar producto-->
        <form action="administra_prod.php" method="POST">
          <input type="hidden" name="cod_prod" value="<?php echo $producto->getcod_producto() ?>"><!--envia id de producto-->
          <input type="submit" value="Eliminar" onclick="this.form.action = '?action=eliminar';">
        </form>
        <!--<a href="?action=eliminar" onclick="return confirm('¿Esta seguro de eliminar este producto?')"> Eliminar</a><p>-->
      </td>
    </tr>
    <?php }?>
  </tbody>
</table>
</body>
</html>