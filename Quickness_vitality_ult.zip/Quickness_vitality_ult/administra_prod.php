<?php

require_once 'crud_producto.php';
require_once 'conexion.php';
require_once 'productos.php';     
$crud=new mach_acces();
$producto= new productos();
$listaproducto=$crud->mostrar_prod();


$db = database::conectar();

if(isset($_REQUEST['action']))
{
    switch ($_REQUEST['action'])
    {
        case 'actualizar':
        $num_prod=$_POST["num_prod"];//id de producto
        $nombre_prod=$_POST["nom_prod"];
        $valor_prod=$_POST["val_prod"];
        $cant_disp=$_POST["cant_disp"]; 
        $costo_prod=$_POST["cost_prod"];
        $marca=$_POST["marca"];
        $proveedor=$_POST["proveedor"];
        $tipo_prod=$_POST["tip_prod"];
        $observacion=$_POST["observacion"];

        $update=new mach_acces();
        $update-> Update_prod($_POST["num_prod"],$_POST["nom_prod"],$_POST["val_prod"],$_POST["cant_disp"],$_POST["cost_prod"],$_POST["marca"],$_POST["proveedor"],$_POST["tip_prod"],$_POST["observacion"]);
        break;

        case 'registrar':

          $num_prod=$_POST["num_prod"];
          $nombre_prod=$_POST["nom_prod"];
          $valor_prod=$_POST["val_prod"];
          $cant_disp=$_POST["cant_disp"];
          $costo_prod=$_POST["cost_prod"];
          $marca=$_POST["marca"];
          $proveedor=$_POST["proveedor"];
          $tipo_prod=$_POST["tip_prod"];
          $observacion=$_POST["observacion"];

        $insert=new mach_acces();
        $insert->Insert_prod($_POST["num_prod"],$_POST["nom_prod"],$_POST["val_prod"],$_POST["cant_disp"],$_POST["cost_prod"],$_POST["marca"],$_POST["proveedor"],$_POST["tip_prod"],$_POST["observacion"]);
        break;

        case 'eliminar':
            $num_prod = $_POST["cod_prod"];
            $delete=new mach_acces();
            $delete-> Delete_prod($_POST["cod_prod"]);
        break;
    }   
}
?>
<html>
<head>
	<title>Actualizar Producto</title>
     <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width, initial-scale=1">
 </head>
<body>
<div >    
<H2>Actualizar Producto </H2>
<form action='#' method='POST'>
		    <input type='hidden' name="num_prod" value="<?php echo $_POST["id_prod"] ?>"> <!--recibe id de producto-->
			<p>Nombre:<br>
			<input type='text' name="nom_prod" placeholder="">

			<p>valor:</br>
			<input type='text' name="val_prod" placeholder="">

			<p>Cantidad Disponible:<br>
			<input type='text' name="cant_disp" placeholder="">

			<p>Costo:<br>
			<td><input type='text' name="cost_prod" placeholder=""></td>

			<p>Marca:<br>
			<input type='text' name="marca" placeholder="">

			<p>Id Proveedor:<br>
			<input type='text' name="proveedor" placeholder="">

			<p>Tipo:<br>
			<input type='text' name="tip_prod" placeholder="">

			<p>Observación:<br>
			<input type='text' name="observacion" placeholder="">

			<input type="submit" value="actualizar" onclick="this.form.action = '?action=actualizar';"/>
	<a href="index_admin.php">Volver</a>
</form>
</div> 
</body>
</html>
<!--<td><form action="administra_prod.php" method="POST"><input type="submit" value="update" onclick="this.form.action = '?action=actualizar';"/></form></a><a href="?action=eliminar" onclick="return confirm('¿Esta seguro de eliminar este producto?')"> Eliminar</a><p></td>-->
<html>
<head></head>
<body>
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
	<div id="insertaprod" name="insertaprod">
    <form name="insertaprod" id="insertaprod" method="POST" action="#">
    <h2>Añadir Producto</h2>
		<input type="text" name="num_prod" placeholder="codigo producto" required><br><br>
		<input type="text" name="nom_prod" placeholder="nombre producto" required><br><br>
		<input type="text" name="val_prod" placeholder="valor producto" required><br><br>
		<input type="text" name="cant_disp" placeholder="cantidad disponible" required><br><br>
		<input type="text" name="cost_prod" placeholder="costo producto" required><br><br>
		<input type="text" name="marca" placeholder="marca" required><br><br>
		<input type="text" name="proveedor" placeholder="proveedor" required><br><br>
		<input type="text" name="tip_prod" placeholder="tipo" required><br><br>
		<input type="text" name="observacion" placeholder="observacion" required><br><br>
		<input type="submit" value="registrar" onclick="this.form.action = '?action=registrar';"/>
		<a href="index_admin.php">Volver</a>
        <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
	</form>
</body>
</html>