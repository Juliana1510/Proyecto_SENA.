<!doctype html>
<html>
    <head>
        <meta charset="UTF-8"/>
        <title>Login</title>
    </head>
    <body>
        <?php 
        class Login
        {
            public function Login_user($user,$pass)
            {

                session_start();
                require_once'conexion.php'; 
                
                //logica
                $db=database::conectar();

                $cont=0;

                $sql2="SELECT * FROM sesion WHERE usu_login='$user'AND password='$pass'";
                $result2 = $db->query($sql2);

                while ($row2=$result2->fetch(PDO::FETCH_ASSOC))
                {
                    $uusername=stripslashes($row2["usu_login"]);
                    $ppasword=stripslashes($row2["password"]);

                    $cont=$cont+1;
                }

                if ($cont==0)
                {


                    print "<script>alert(\"Usuario y/o contraseña incorrectos.\");window.location='html/inicio_sesion.html';</script>";

                }

                if ($cont!=0)
                {
                    $_SESSION['usu_login']=$uusername;


                    $sql1="SELECT fk_rol FROM persona WHERE pk_fk_usu_login='$uusername'";
                    $result1=$db->query($sql1);


                    while ($row1=$result1->fetch(PDO::FETCH_ASSOC))
                    {
                        $role=stripslashes($row1["fk_rol"]);
                    }

                    if (@$role===null)
                    {
                        print "<script>alert(\"Usuario no tiene asignado rol.\");window.location='html/inicio_sesion.html';</script>";
                    }

                    if (@$role==='Administrador')
                    {
                        $_SESSION['active']=1;
                        header('location:index_admin.php'); //direcciona a pagina incio admin - toca cambiar por php
                    }

                    elseif (@$role==='Auxiliar')
                    {
                        $_SESSION['active']=1;
                        header('location:index_aux.php');  //direcciona a pagina incio auxi - toca cambiar por php
                    }
                    elseif (@$role==='Contador')
                    {
                        $_SESSION['active']=1;
                        header('location:index_conta.php'); //direcciona a pagina incio conta - toca cambiar por php
                    }
                    else
                    {
                        print "<script>alert(\"Ha ocurrido un error\");window.location='html/inicio_sesion.html';</script>";
                    }
                }//finalizando conteo

            }//finalizando metodo

        }//cerrando la clase
        $Nuevo=new Login();
        $Nuevo->Login_user($_POST["user"],$_POST["pass"]); //POST:nombre de usuario= "user" y contraseña = "pass"
        ?>    
    </body>
</html>