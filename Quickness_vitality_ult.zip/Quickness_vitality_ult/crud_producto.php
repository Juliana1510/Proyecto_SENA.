<?php
require_once "conexion.php";
	class mach_acces
	{
		private $pdo;
		public function __CONSTRUCT()
		{
			try {
				$this->pdo=database::conectar();
			} 
			catch (Exception $ex){
				die($e-> getMessage());
			}
		}

		public function Insert_prod($num_prod,$nombre_prod,$valor_prod,$cant_disp,$costo_prod,$marca,$proveedor,$tipo_prod,$observacion)
		{

			$sql = "INSERT INTO productos (cod_producto, nom_producto, valor_producto, cantidad_disp, costo, fk_marca, fk_proveedor_id, fk_tipo_prod,observacion_prod) VALUES ('$num_prod','$nombre_prod','$valor_prod','$cant_disp','$costo_prod','$marca','$proveedor','$tipo_prod','$observacion')";

			$this->pdo->query($sql);

			print "<script>alert(\"Producto Agregado Exitosamente.\");window.location='index_admin.php';</script>";
		}

		public function Update_prod($num_prod,$nombre_prod,$valor_prod,$cant_disp,$costo_prod,$marca,$proveedor,$tipo_prod,$observacion)
		{

			$sql="UPDATE productos SET nom_producto='$nombre_prod',valor_producto='$valor_prod',cantidad_disp='$cant_disp', costo='$costo_prod',   fk_marca='$marca', fk_proveedor_id='$proveedor', fk_tipo_prod='$tipo_prod', observacion_prod='$observacion' WHERE cod_producto='$num_prod'";

			$this->pdo->query($sql);

			print "<script>alert(\"Producto Actualizado exitosamente.\");window.location='index_admin.php';</script>";
		}

		public function Delete_prod($num_prod)
		{

			$sql="DELETE FROM productos WHERE cod_producto='$num_prod'";

			$this->pdo->query($sql);

			print "<script>alert(\"Registro Eliminado exitosamente.\");window.location='index_admin.php';</script>";
		}

		public function mostrar_prod(){
			$db=database::conectar();
			$listaproducto=[];
			$select=$db->query('SELECT * FROM productos');
            
			foreach($select->fetchAll() as $producto){
				$myproducto= new productos();
				$myproducto->setcod_producto        ($producto['cod_producto']);
				$myproducto->setnom_producto        ($producto['nom_producto']);
				$myproducto->setvalor_producto      ($producto['valor_producto']);
				$myproducto->setcantidad_disp       ($producto['cantidad_disp']);
                $myproducto->setcosto               ($producto['costo']);
                $myproducto->setfk_marca         ($producto['fk_marca']);
                $myproducto->setfk_proveedor_id     ($producto['fk_proveedor_id']);
				$myproducto->setfk_tipo_prod        ($producto['fk_tipo_prod']);
				$myproducto->setobservacion_prod    ($producto['observacion_prod']);
				$listaproducto[]=$myproducto;
			}
			return $listaproducto;
		}
	}
?>