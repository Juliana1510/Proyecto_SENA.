<?php
	class productos{
		private $cod_producto;
		private $nom_producto;
		private $valor_producto;
        private $cantidad_disp;
        private $costo;
        private $fk_marca_id;
        private $fk_proveedor_id;
        private $fk_tipo_prod;
        private $observacion_prod;

   function __construct(){}
                
        public function getcod_producto(){
			return $this->cod_producto;
		} 
		public function getnom_producto(){
		    return $this->nom_producto;
		}            
        public function getvalor_producto(){
			return $this->valor_producto;
		}
        public function getcantidad_disp(){
			return $this->cantidad_disp;
		}
        public function getcosto(){
			return $this->costo;
		}
        public function getfk_marca(){
			return $this->fk_marca;
		}
        public function getfk_proveedor_id(){
			return $this->fk_proveedor_id;
		}
        public function getfk_tipo_prod(){
			return $this->fk_tipo_prod;
		}
        public function getobservacion_prod(){
			return $this->observacion_prod;
		}
            
        
        public function setcod_producto($cod_producto){
			$this->cod_producto = $cod_producto;
		}       
		public function setnom_producto($nom_producto){
			$this->nom_producto = $nom_producto;
		} 
		public function setvalor_producto($valor_producto){
			$this->valor_producto = $valor_producto;
		}
		public function setcantidad_disp($cantidad_disp){
			$this->cantidad_disp = $cantidad_disp ; 
		}
        public function setcosto($costo){
			$this->costo = $costo ; 
		}
        public function setfk_marca($fk_marca){
			$this->fk_marca = $fk_marca ; 
		}
        public function setfk_proveedor_id($fk_proveedor_id){
			$this->fk_proveedor_id = $fk_proveedor_id ; 
		}
        public function setfk_tipo_prod($fk_tipo_prod){
			$this->fk_tipo_prod = $fk_tipo_prod ; 
		}
        public function setobservacion_prod($observacion_prod){
			$this->observacion_prod = $observacion_prod ; 
		}
	}
?>