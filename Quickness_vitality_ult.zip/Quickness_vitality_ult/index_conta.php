<?php

require_once 'crud_producto.php';
require_once 'conexion.php';
require_once 'productos.php';      
$crud=new mach_acces();
$producto= new productos();
$listaproducto=$crud->mostrar_prod();


$db = database::conectar();

if(isset($_REQUEST['action']))
{
    switch ($_REQUEST['action'])
    {
        case 'actualizar':
        $num_prod=$_POST["num_prod"];
        $nombre_prod=$_POST["nom_prod"];
        $valor_prod=$_POST["val_prod"];
        $cant_disp=$_POST["cant_disp"]; 
        $costo_prod=$_POST["cost_prod"];
        $idmarca=$_POST["marca"];
        $proveedor=$_POST["proveedor"];
        $tipo_prod=$_POST["tip_prod"];
        $observacion=$_POST["observacion"];

        $update=new mach_acces();
        $update-> Update_prod($_POST["num_prod"],$_POST["nom_prod"],$_POST["val_prod"],$_POST["cant_disp"],$_POST["cost_prod"],$_POST["marca"],$_POST["proveedor"],$_POST["tip_prod"],$_POST["observacion"]);
        break;

        case 'registrar':

          $num_prod=$_POST["num_prod"];
          $nombre_prod=$_POST["nom_prod"];
          $valor_prod=$_POST["val_prod"];
          $cant_disp=$_POST["cant_disp"]; 
          $costo_prod=$_POST["cost_prod"];
          $idmarca=$_POST["marca"];
          $proveedor=$_POST["proveedor"];
          $tipo_prod=$_POST["tip_prod"];
          $observacion=$_POST["observacion"];

        $insert=new mach_acces();
        $insert->Insert_prod($_POST["num_prod"],$_POST["nom_prod"],$_POST["val_prod"],$_POST["cant_disp"],$_POST["cost_prod"],$_POST["marca"],$_POST["proveedor"],$_POST["tip_prod"],$_POST["observacion"]);
        break;

        case 'eliminar':
            $delete=new mach_acces();
            $delete-> Delete_prod($_GET["cod_producto"]);
        break;

        case 'editar':
        $capt = $_GET["cod_producto"];
        break;
    }   
}
?>


<html>
	<head>
      <link rel="shortcut icon" href="../imagenes/icono.png">
      <title>Pagina principal</title>
      <link rel="stylesheet" href="./css/estilo.css"/>
  </head>
      <body>
        <nav id="menu-h">
          </a>
            <ul>
              <li><a  href="#">Papelera</a></li> <!--falta archivo de papelera-->
              <li><a  href="./html/index.html">Salir</a></li>
            </ul>
        </nav><br>
<!--EDITADO-->
        <SELECT class="filtro" NAME=""> 
          <option disabled selected>Filtrar</option>
          <OPTION VALUE="">Medicamentos
          <OPTION VALUE="">Populares
          <OPTION VALUE="">Cosmeticos
          <OPTION VALUE="">Droga Blanca
        </SELECT>

        <li><a class="btn" href="./html/Factura.html">FACTURAS</a></li>
        <li><a class="btn" href="#">REPORTE DE VENTAS</a></li><!--falta archivo de reporte de ventas-->
        <li><a class="btn" href="./html/Historial_ventas.html">HISTORIAL DE VENTAS</a></li>

  <table summary="tabla conta">
    <br><br><br>
  <thead>
    <tr>
      <th scope="col">Codigo</th>
      <th scope="col">Nombre</th>
      <th scope="col">valor</th>
      <th scope="col">Cantidad Disponible</th>
      <th scope="col">Costo</th>
      <th scope="col">Marca</th>
      <th scope="col">Proveedor</th>
      <th scope="col">Tipo</th>
      <th scope="col">Observacion</th>
    </tr>
  </thead>
  <tbody>
  <?php foreach ($listaproducto as $producto) {?>
    <tr>
      <td><?php echo $producto->getcod_producto() ?></td>
      <td><?php echo $producto->getnom_producto() ?></td>
      <td><?php echo $producto->getvalor_producto() ?></td>
      <td><?php echo $producto->getcantidad_disp() ?></td>
      <td><?php echo $producto->getcosto() ?></td>
      <td><?php echo $producto->getfk_marca_id() ?></td>
      <td><?php echo $producto->getfk_proveedor_id() ?></td>
      <td><?php echo $producto->getfk_tipo_prod() ?></td>
      <td><?php echo $producto->getobservacion_prod() ?></td>
    </tr>
    <?php }?>
  </tbody>

</table>

</body>
</html>