<?php

require_once '../model/model_mach.php';
require_once '../BD/conexion.php';

$db = database::conectar();

if(isset($_REQUEST['action']))
{
	switch ($_REQUEST['action'])
	{
		case 'actualizar':

		//espacio q genera el almacenamiento de las imganes
		$file=$_FILES['image_m_a']['name'];
		$ruta_file=$_FILES['image_m_a']['tmp_name'];
		$file_foto="../images/ b".$file; //kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk

		//se copia archivo a la carpeta file
		copy($ruta_file, $file_foto);

		$update=new mach_acces();
		$update-> Update_mach_acces($_POST["mach_acces_name2"],$_POST["mach_acces_name"],$_POST["mach_status"],$file_foto);
		break;

		case 'registrar':

		//espacio que genera el almacenamiento de las imagenes
		$file=$_FILES['image_m_a']['name'];
		$ruta_file=$_FILES['image_m_a']['tmp_name'];
		$file_foto="../images/ b".$file; //kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk

		copy($ruta_file, $file_foto);

		$insert=new mach_acces();
		$insert->Insert_mach_acces($_POST["mach_acces_name"],$_POST["mach_status"],$file_foto);
		break;

		//caso para metodo eliminar
		case 'eliminar':
			$delete=new mach_acces();
			$delete-> Delete_mach_acces($_GET["mach_acces_name"]);
		break;

		//caso para metodo editar
		case 'editar':
		$capt = $_GET["mach_acces_name"];
		break;
	}	
}
?>

<!DOCTYPE html>
<html lang="es">
<head> 
	<title> EJEMPLO INSTRUCTOR-LEONARDO</title>
	<LINK rel= "stylesheet" type="text/css" href="../css/style_crud.css">

</head>
<body>
	<br> <a href=" ?action=ver&m=1" class=" btn1">NEW MACHINE OR ACCESORY</a><BR><BR>

	<?php
	if(!empty($_GET['m']) and !empty($_GET['action']) ) {?>

<div> 
	<!-- formulario nuevo regustro, multipart/form-data es necesario si sus usuarios deben subir un archivo a traves del formulario  -->
	<form action="" method="post" enctype="multipart/form-data">
		<h2>New machine or accesory</h2>
		<label> Machine-accesory: </label>
		<input type="text" name="mach_acces_name" placeholder="Machine-accesory"required>
		<label> Machine-accesory photo</label>
		<p> <input type="file" name="image_m_a" required>
		<p> <label>Machine acessory state:</label>
		<br> active <input type="radio" name="mach_acces_status" value="1"cheked>
		inactive <input type="radio" name="mach_acces_status" value="0">
		<p> <input type="submit-button" type="submit" value="Save" onclick = "this.form.action ='?action=registrar';"/>
	</form>
</div>
<?php } ?>

<?php if (!empty($_GET['mach_acces_name'])&& !empty($_GET['action'])  ){?>

<div>
	<!--multipart/form-data es necesario si sus usuarios dben subir un archivo a trves del formulario-->
	<form action="#" method="post" enctype="multipart/form-data">
		<?php $sql1 = "SELECT * FROM machines_accesories WHERE mach_acces_name = '$capt'";
		$query = $db -> query($sql1);

		while ($row=$query->fetch(PDO::FETCH_ASSOC))
		{
			?>
			<H2>UPDATE  MACHINE OR ACCESSORY </H2>
			<IMG srs="<?php echo $row["image_m_a"]; ?>" width="100" height="100"><p>
			<label>Machine-accesorry </label>
			<input type="text" name="mach_acces_name" value="<?php echo $row["mach_acces_name"]; ?>" style="display:none">
			<input type="text" name="mach_acces_name2" value="<?php echo $row["mach_acces_name"]; ?>" placeholder="mach_acces" required>
			<label>Machine-accesorry photo</label>
			<p><input type="file" name="image_m_a" required>
			<p><label>Machine accesorry state: </label>
			<br>active<input type="radio" name="mach_status" value="1" <?php echo $row["mach_acces_status"]==='1' ?'checked':''?>>
			inactive <input type="radio" name="mach_status" value="0" <?php echo $row['mach_acces_status']==='0'?'cheked':''?>>
			<p><input type="submit" value="update" onclick="this.form.action = '?action=actualizar';"/>
			</form>
			</div>
		<?php 
		}
	}

$sql1="SELECT * FROM machines_accesories";
$query=$db-> query($sql1);

if ($query->rowCount()>0 ):?>
<h1>Machine or accesories records</h1><br>

<?php while ($row=$query->fetch(PDO::FETCH_ASSOC)): ?>

<div class="ex2">
	<img srs="<?php echo $row["image_m_a"]; ?>" width="200" height="100"><br>
	<?php echo $row['mach_acces_name']."<br>";


	if ($row['mach_acces_status']==1){
		echo "Active"."<br>";
	}else{
		echo "inactive"."<br>";
	} ?>
	<a href="?action=editar&mach_acces_name= <?php echo $row["mach_acces_name"]; ?>"> Update </a>
	<a href="?action=eliminar&mach_acces_name= <?php echo $row["mach_accesa-name"]; ?>" onclick="return confirm('¿Esta seguro de eliminar este usuario?')"> Delete</a><p>
</div> 
<?php endwhile; ?>
<?php else: ?>
	<h4 class="alert alert-danger">Mr. User Do Not Find Registration</h4>
	<?php endif; ?>
</body>
</html>
