<?php
require_once "conexion.php";


	class registro
	{
		private $pdo;
		public function __CONSTRUCT()
		{
			try {
				$this->pdo=database::conectar();
			} 
			catch (Exception $ex){
				die($e-> getMessage());
			}
		}

		public function Insert_sesion($usuario,$contra)
		{
			//$usuario=$_POST["usuario"];
			//$contra=$_POST["contra"];

			$sql = "INSERT INTO sesion(usu_login, contraseña) VALUES ('$usuario','$contra')";

			$this->pdo->query($sql);

			print "<script>alert(\"Usuario Registrado Exitosamente.\");window.location='./html/info_tdoc.html';</script>";//falta archivo para registrar info. persona ---------------------------------------------
		}//----------------------------------------------------------------------------------------------------------

        public function Insert_tdoc($num_doc,$tipo,$estado)
		{

			//$num_doc=$_POST["num_doc"];
			//$tipo=$_POST["tipo"];
			//$estado=$_POST["estado"];

			$sql = "INSERT INTO tipo_documento(tdoc, desc_tdoc, estado_tdoc) VALUES ('$num_doc','$tipo','$estado')";

			$this->pdo->query($sql);

			print "<script>alert(\"Información de Usuario Registrada Exitosamente.\");window.location='./html/info_rol.html';</script>";//falta archivo para registrar info. persona
		}//----------------------------------------------------------------------------------------------------------

        public function Insert_rol($codigo_rol,$rol)
		{
			//$codigo_rol=$_POST["codigo_rol"];
			//$rol=$_POST["rol"];

			$sql = "INSERT INTO roles(cod_rol, desc_rol) VALUES ('$codigo_rol','$rol')";

			$this->pdo->query($sql);

			print "<script>alert(\"Información de Usuario Registrada Exitosamente.\");window.location='./html/info_persona.html';</script>";//falta archivo para registrar info. persona
		}//----------------------------------------------------------------------------------------------------------

        public function Insert_persona($num_doc,$usuario,$nombre,$nombre2,$apellido,$apellido2,$direccion,$telefono,$codigo_rol)
		{
			//$nombre=$_POST["nombre"];
			//$nombre2=$_POST["nombre2"];
			//$apellido=$_POST["apellido"];
			//$apellido2=$_POST["apellido2"];
			//$direccion=$_POST["direccion"];
			//$telefono=$_POST["telefono"];

			$sql = "INSERT INTO persona(pk_fk_tdoc,id_persona, pk_fk_usu_login, nom_persona, nom2_persona, apellido_persona, apellido2_persona, direccion_persona, telefono, rol) VALUES ('$num_tdoc','','$usuario','$nombre','$nombre2','$apellido','$apellido2','$direccion','$telefono','$codigo_rol')";

			$this->pdo->query($sql);

			print "<script>alert(\"Usuario Registrado Exitosamente.\");window.location='./html/Inicio_sesion.html';</script>";//falta archivo para registrar info. persona
		}//----------------------------------------------------------------------------------------------------------
	}
	$insert=new registro();
	//$insert-> registro($_POST["usuario"],$_POST["contra"],$_POST["num_doc"],$_POST["tipo"],$_POST["estado"],$_POST["codigo_rol"],$_POST["rol"],$_POST["nombre"],$_POST["nombre2"],$_POST["apellido"],$_POST["apellido2"],$_POST["direccion"],$_POST["telefono"]);
	$insert-> Insert_sesion($_POST["usuario"],$_POST["contra"]);

?>