<?php
require_once "conexion.php";
	class mach_acces
	{
		private $pdo;
		public function __CONSTRUCT()
		{
			try {
				$this->pdo=database::conectar();
			} 
			catch (Exception $ex){
				die($ex-> getMessage());
			}
		}

		public function Insert_fact($num_fact,$fecha_fact,$subtotal_fact,$iva_fact,$total_fact,$observacion_fact)
		{

			$sql = "INSERT INTO factura (n_factura, fecha_factura, subtotal, iva, total_factura, observacion_fact) VALUES ('$num_fact','$fecha_fact','$subtotal_fact','$iva_fact','$total_fact','$observacion_fact')";

			$this->pdo->query($sql);

			print "<script>alert(\"Factura Agregada Exitosamente.\");window.location='index_aux.html';</script>";
		}

		public function Update_fact($num_fact,$fecha_fact,$subtotal_fact,$iva_fact,$total_fact,$observacion_fact)
		{

			$sql="UPDATE productos SET fecha_factura='$fecha_fact',subtotal='$subtotal_fact',iva='$iva_fact', total_factura='$total_fact', observacion_fact='$observacion_fact' WHERE n_factura='$num_fact'";

			$this->pdo->query($sql);

			print "<script>alert(\"Factura Actualizada Exitosamente.\");window.location='index_aux.html';</script>";
		}

		public function Delete_fact($num_fact)
		{

			$sql="DELETE FROM factura WHERE n_factura='$num_fact'";

			$this->pdo->query($sql);

			print "<script>alert(\"Factura Eliminada Exitosamente.\");window.location='index_aux.html';</script>";
		}
	}
?>